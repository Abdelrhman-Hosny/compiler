int main()
{
    x = 5;
    int x = 5;
    float x = 5.3;
    char m = 'm';
    const char m = 'm';
    const float x = 3.3;
    const int x = 'b';
    bl = 1;

}