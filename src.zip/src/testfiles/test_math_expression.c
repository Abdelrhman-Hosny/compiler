

int main()
{
    int x = x + 2;
    int x = x + 2;
    (x*2) + 2;
    (x-3) - 3;
    x-y((x(x)));
    x%3;
    -X/3;
    x*3.2;
    3.2*3;
    3.2/3;
    X*Y;
}