int main()
{
    for (int i = 0;;)
    {
        continue;
    }
    
    for (int i = 0; i < 10; i = i + 1)
    {
        break;
    }

    for (i = 0; i < 10; i = i + 1)
    {
    }
    {
    }

    for (;i < 10; i = i + 1)
    {
    }

    for (;i < 10;)
    {
    }

    for (;;)
    {
    }

    do {

    } while (i < 10);

    do {

    } while();

    while (i > 2)
    {
    }

    while()
    {
    }

    while(0)
    {
    }

}