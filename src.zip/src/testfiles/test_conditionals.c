int main()
{
    if ( 1 )
    {
    }
    else
    {
    }

    if ( x == 5)
    {
    }
    else if ( x == 6)
    {
    }
    else if (x != 4)
    {
        if (x == 5)
        {
        }
        else if (x == 6)
        {
        }
    }
    else
    {
    }

    if (x == 5)
    {
    }
 
    switch (x)
    {
    case 2:
        x = 3; 
    case 5:
        x = 4;
    case 6:
        break;
    default:
        break;
    }

    switch (x)
    {
        default:
            break;
    }

}