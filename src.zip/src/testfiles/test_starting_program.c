int x = 5;

int main()
{
    return 0;
}

int y = 3;

int z = 5;

int geh()
{
    return;
}
